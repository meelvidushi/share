"""External component-tree kernels."""
