from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Callable, ClassVar

from kernel_sdk import (
    Kernel,
    KernelConfigurationError,
    KernelDispatcher,
    KernelExecutionError,
    KernelRuntimeContext,
    KernelSubtreeResult,
    ResolvedComponentNode,
    resolve_bindings,
)


class AggregateOrcKernel(Kernel):
    """Deterministic aggregator that combines already-computed upstream results.

    Reads values via the standard `input_bindings` channel and/or `subresult_sources`
    (a direct read of an upstream node's children, for aggregating a domain's day-by-day
    results without threading each one through an individual input binding), applies a
    config-driven list of typed operations, and returns derived output — no LLM call.
    """

    kind: ClassVar[str] = "aggregate_orc"

    async def execute(
        self,
        node: ResolvedComponentNode,
        runtime_context: KernelRuntimeContext,
        runtime_sources: Mapping[str, Any],
        runtime: KernelDispatcher,
    ) -> KernelSubtreeResult:
        config = (node.kernel.config if node.kernel else None) or {}
        operations = config.get("operations") or []
        output_spec = config.get("output") or {}
        subresult_sources = config.get("subresult_sources") or []
        if not isinstance(operations, list):
            raise KernelConfigurationError("aggregate_orc.config.operations must be a list")
        if not isinstance(output_spec, Mapping):
            raise KernelConfigurationError("aggregate_orc.config.output must be a mapping")
        if not isinstance(subresult_sources, list):
            raise KernelConfigurationError("aggregate_orc.config.subresult_sources must be a list")

        bindings: dict[str, Any] = dict(
            resolve_bindings(
                node.local_metadata.input_bindings if node.local_metadata else None,
                runtime_sources,
                runtime_context.node_results,
            )
        )
        for source in subresult_sources:
            target_name, items = _resolve_subresult_source(source, runtime_context.node_results)
            bindings[target_name] = items

        ops_results: dict[str, Any] = {}
        for index, operation in enumerate(operations):
            if not isinstance(operation, Mapping):
                raise KernelConfigurationError(f"aggregate_orc operation #{index} must be an object")
            operation_id = operation.get("id")
            operation_kind = operation.get("op")
            if not isinstance(operation_id, str) or not operation_id:
                raise KernelConfigurationError(f"aggregate_orc operation #{index} requires a string 'id'")
            if not isinstance(operation_kind, str) or not operation_kind:
                raise KernelConfigurationError(f"aggregate_orc operation '{operation_id}' requires a string 'op'")
            handler = _OPERATIONS.get(operation_kind)
            if handler is None:
                raise KernelConfigurationError(
                    f"aggregate_orc operation '{operation_id}' references unknown op '{operation_kind}'"
                )
            ops_results[operation_id] = handler(operation, bindings, ops_results)

        node_id = (
            node.local_metadata.node_id
            if node.local_metadata and node.local_metadata.node_id
            else node.component_id
        )
        result = KernelSubtreeResult(
            component_id=node.component_id,
            node_id=node_id,
            kernel_kind=node.kernel.kind if node.kernel else self.kind,
            output=_build_output(output_spec, bindings, ops_results),
        )
        runtime_context.store_node_result(node_id, result)
        return result


# subresult sources ------------------------------------------------------------


def _resolve_subresult_source(
    source: Mapping[str, Any],
    node_results: Mapping[str, Any],
) -> tuple[str, list[dict[str, Any]]]:
    """Read an upstream node's direct children and surface them as flat dicts.

    Each child contributes its `output` keys plus, when requested, `reasoning`/`evidence`.
    Exposed under `bindings[target_name]` for operations to consume via `$bindings.<name>`.
    """
    if not isinstance(source, Mapping):
        raise KernelConfigurationError("aggregate_orc subresult_source must be an object")
    target_name = source.get("target_name")
    source_node_id = source.get("source_node_id")
    if not isinstance(target_name, str) or not target_name:
        raise KernelConfigurationError("aggregate_orc subresult_source requires a string 'target_name'")
    if not isinstance(source_node_id, str) or not source_node_id:
        raise KernelConfigurationError(
            f"aggregate_orc subresult_source '{target_name}' requires a string 'source_node_id'"
        )

    parent_result = node_results.get(source_node_id)
    if parent_result is None:
        return target_name, []

    include_reasoning = bool(source.get("include_reasoning", False))
    include_evidence = bool(source.get("include_evidence", False))

    items: list[dict[str, Any]] = []
    for child in getattr(parent_result, "children", None) or []:
        child_output = getattr(child, "output", None) or {}
        item = dict(child_output)
        if include_reasoning:
            item["reasoning"] = getattr(child, "reasoning", None)
        if include_evidence:
            evidence = getattr(child, "evidence", None) or []
            item["evidence"] = [
                ev.model_dump(mode="json") if hasattr(ev, "model_dump") else ev for ev in evidence
            ]
        items.append(item)
    return target_name, items


# path resolution ---------------------------------------------------------------


def _build_output(spec: Any, bindings: Mapping[str, Any], ops_results: Mapping[str, Any]) -> Any:
    if isinstance(spec, Mapping):
        return {key: _build_output(value, bindings, ops_results) for key, value in spec.items()}
    if isinstance(spec, list):
        return [_build_output(item, bindings, ops_results) for item in spec]
    return _resolve(spec, bindings, ops_results)


def _resolve(spec: Any, bindings: Mapping[str, Any], ops_results: Mapping[str, Any]) -> Any:
    """Resolve a `$bindings.<path>` / `$ops.<path>` reference; anything else is a literal."""
    if not isinstance(spec, str) or not spec.startswith("$"):
        return spec
    head, _, tail = spec[1:].partition(".")
    if head == "bindings":
        root: Any = bindings
    elif head == "ops":
        root = ops_results
    else:
        raise KernelConfigurationError(f"aggregate_orc path '{spec}' must start with $bindings or $ops")
    if not tail:
        return root
    cursor: Any = root
    for part in tail.split("."):
        if isinstance(cursor, Mapping):
            if part not in cursor:
                return None
            cursor = cursor[part]
        elif isinstance(cursor, list) and part.lstrip("-").isdigit():
            index = int(part)
            cursor = cursor[index] if -len(cursor) <= index < len(cursor) else None
        else:
            return None
    return cursor


# helpers -------------------------------------------------------------------


def _items(operation: Mapping[str, Any], bindings: Mapping[str, Any], ops_results: Mapping[str, Any]) -> list[Any]:
    raw = _resolve(operation.get("items"), bindings, ops_results)
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise KernelExecutionError(
            f"aggregate_orc op '{operation.get('id')}' expected a list for 'items', got {type(raw).__name__}"
        )
    return raw


def _field(item: Any, field: str | None) -> Any:
    if field is None:
        return item
    if isinstance(item, Mapping):
        return item.get(field)
    return getattr(item, field, None)


def _matches(item: Any, where: Mapping[str, Any]) -> bool:
    return all(_field(item, key) == expected for key, expected in where.items())


# operations ------------------------------------------------------------------
#
# Deliberately minimal and generic (min/max/count/filter over a list of items) rather
# than baking in specific clinical decision rules — compose the actual business logic
# from these primitives in `config.operations`, don't extend this file with rules that
# can't be verified against a real spec.


def _op_min(
    operation: Mapping[str, Any],
    bindings: Mapping[str, Any],
    ops_results: Mapping[str, Any],
) -> Any:
    values = [
        value
        for value in (
            _field(item, operation.get("field")) for item in _items(operation, bindings, ops_results)
        )
        if value is not None
    ]
    return min(values) if values else _resolve(operation.get("default"), bindings, ops_results)


def _op_max(
    operation: Mapping[str, Any],
    bindings: Mapping[str, Any],
    ops_results: Mapping[str, Any],
) -> Any:
    values = [
        value
        for value in (
            _field(item, operation.get("field")) for item in _items(operation, bindings, ops_results)
        )
        if value is not None
    ]
    return max(values) if values else _resolve(operation.get("default"), bindings, ops_results)


def _op_count(
    operation: Mapping[str, Any],
    bindings: Mapping[str, Any],
    ops_results: Mapping[str, Any],
) -> int:
    where = operation.get("where") or {}
    if not isinstance(where, Mapping):
        raise KernelConfigurationError(f"aggregate_orc count op '{operation.get('id')}' 'where' must be an object")
    return sum(1 for item in _items(operation, bindings, ops_results) if _matches(item, where))


def _op_filter(
    operation: Mapping[str, Any],
    bindings: Mapping[str, Any],
    ops_results: Mapping[str, Any],
) -> list[Any]:
    where = operation.get("where") or {}
    select = operation.get("select")
    if not isinstance(where, Mapping):
        raise KernelConfigurationError(f"aggregate_orc filter op '{operation.get('id')}' 'where' must be an object")
    if select is not None and not isinstance(select, list):
        raise KernelConfigurationError(
            f"aggregate_orc filter op '{operation.get('id')}' 'select' must be a list of field names"
        )
    matched = [item for item in _items(operation, bindings, ops_results) if _matches(item, where)]
    if select is None:
        return matched
    return [{field: _field(item, field) for field in select} for item in matched]


_OPERATIONS: dict[str, Callable[[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]], Any]] = {
    "min": _op_min,
    "max": _op_max,
    "count": _op_count,
    "filter": _op_filter,
}
