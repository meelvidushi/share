from __future__ import annotations

import pytest

from kernel_sdk import (
    KernelConfigurationError,
    KernelSpec,
    KernelSubtreeResult,
    LocalNodeMetadata,
    ResolvedComponentNode,
)
from kernel_sdk.testing import FakeKernelDispatcher, make_runtime_context
from kernels.aggregate_orc import AggregateOrcKernel


def _domain_node(config: dict, *, node_id: str = "node.aggregate") -> ResolvedComponentNode:
    return ResolvedComponentNode(
        component_id="component.aggregate",
        major_version=1,
        minor_version=0,
        save_version=0,
        name="Domain Aggregate",
        purpose="purpose",
        kernel=KernelSpec(kind="aggregate_orc", config=config),
        local_metadata=LocalNodeMetadata(node_id=node_id),
    )


@pytest.mark.asyncio
async def test_aggregate_orc_min_over_filtered_subresult_source() -> None:
    parent_result = KernelSubtreeResult(
        component_id="component.parent",
        node_id="node.parent",
        kernel_kind="flat_prompt",
        children=[
            KernelSubtreeResult(
                component_id="component.day1",
                kernel_kind="flat_prompt",
                output={"day": 1, "anchoring": True, "outcome": "MET"},
            ),
            KernelSubtreeResult(
                component_id="component.day2",
                kernel_kind="flat_prompt",
                output={"day": 2, "anchoring": True, "outcome": "NOT_MET"},
            ),
            KernelSubtreeResult(
                component_id="component.day3",
                kernel_kind="flat_prompt",
                output={"day": 3, "anchoring": False, "outcome": "MET"},
            ),
        ],
    )
    context = make_runtime_context(node_results={"node.parent": parent_result})

    config = {
        "subresult_sources": [
            {"target_name": "days", "source_node_id": "node.parent"},
        ],
        "operations": [
            {
                "id": "anchoring_days",
                "op": "filter",
                "items": "$bindings.days",
                "where": {"anchoring": True},
            },
            {
                "id": "lowest_anchoring_day",
                "op": "min",
                "items": "$ops.anchoring_days",
                "field": "day",
                "default": 99,
            },
        ],
        "output": {"orc_day": "$ops.lowest_anchoring_day"},
    }
    node = _domain_node(config)

    result = await AggregateOrcKernel().execute(
        node, context, {"payload": {}}, FakeKernelDispatcher()
    )

    assert result.output == {"orc_day": 1}
    assert result.node_id == "node.aggregate"
    assert result.kernel_kind == "aggregate_orc"
    assert context.node_results["node.aggregate"] == result


@pytest.mark.asyncio
async def test_aggregate_orc_min_falls_back_to_default_when_no_items_match() -> None:
    parent_result = KernelSubtreeResult(
        component_id="component.parent",
        kernel_kind="flat_prompt",
        children=[
            KernelSubtreeResult(
                component_id="component.day1",
                kernel_kind="flat_prompt",
                output={"day": 1, "anchoring": False},
            ),
        ],
    )
    context = make_runtime_context(node_results={"node.parent": parent_result})
    config = {
        "subresult_sources": [{"target_name": "days", "source_node_id": "node.parent"}],
        "operations": [
            {
                "id": "anchoring_days",
                "op": "filter",
                "items": "$bindings.days",
                "where": {"anchoring": True},
            },
            {
                "id": "lowest_anchoring_day",
                "op": "min",
                "items": "$ops.anchoring_days",
                "field": "day",
                "default": 3,
            },
        ],
        "output": {"orc_day": "$ops.lowest_anchoring_day"},
    }
    node = _domain_node(config)

    result = await AggregateOrcKernel().execute(
        node, context, {"payload": {}}, FakeKernelDispatcher()
    )

    assert result.output == {"orc_day": 3}


@pytest.mark.asyncio
async def test_aggregate_orc_count_operation() -> None:
    parent_result = KernelSubtreeResult(
        component_id="component.parent",
        kernel_kind="flat_prompt",
        children=[
            KernelSubtreeResult(component_id="component.a", kernel_kind="flat_prompt", output={"outcome": "MET"}),
            KernelSubtreeResult(component_id="component.b", kernel_kind="flat_prompt", output={"outcome": "NOT_MET"}),
            KernelSubtreeResult(component_id="component.c", kernel_kind="flat_prompt", output={"outcome": "MET"}),
        ],
    )
    context = make_runtime_context(node_results={"node.parent": parent_result})
    config = {
        "subresult_sources": [{"target_name": "criteria", "source_node_id": "node.parent"}],
        "operations": [
            {"id": "met_count", "op": "count", "items": "$bindings.criteria", "where": {"outcome": "MET"}},
        ],
        "output": {"met_count": "$ops.met_count"},
    }
    node = _domain_node(config)

    result = await AggregateOrcKernel().execute(
        node, context, {"payload": {}}, FakeKernelDispatcher()
    )

    assert result.output == {"met_count": 2}


@pytest.mark.asyncio
async def test_aggregate_orc_missing_op_raises() -> None:
    config = {"operations": [{"id": "x"}], "output": {}}
    node = _domain_node(config)

    with pytest.raises(KernelConfigurationError, match="requires a string 'op'"):
        await AggregateOrcKernel().execute(
            node, make_runtime_context(), {"payload": {}}, FakeKernelDispatcher()
        )


@pytest.mark.asyncio
async def test_aggregate_orc_unknown_op_raises() -> None:
    config = {"operations": [{"id": "x", "op": "does_not_exist"}], "output": {}}
    node = _domain_node(config)

    with pytest.raises(KernelConfigurationError, match="unknown op"):
        await AggregateOrcKernel().execute(
            node, make_runtime_context(), {"payload": {}}, FakeKernelDispatcher()
        )


@pytest.mark.asyncio
async def test_aggregate_orc_missing_subresult_source_id_raises() -> None:
    config = {
        "subresult_sources": [{"target_name": "days"}],
        "operations": [],
        "output": {},
    }
    node = _domain_node(config)

    with pytest.raises(KernelConfigurationError, match="requires a string 'source_node_id'"):
        await AggregateOrcKernel().execute(
            node, make_runtime_context(), {"payload": {}}, FakeKernelDispatcher()
        )
